package com.Automation.RecoAccounts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class CommonLibrary {
	WebDriver driver;
	
 
	
	public void eventhandle(WebDriver ldriver,String event,String locator,String property,String value) {
		
		this.driver=ldriver;
		
		switch (event) {
		case "CLICK":
			if (locator.equals("XPATH")) {
				
				driver.findElement(By.xpath(property)).click();
				break;
				
			}
			else if (locator.equals("ID")) {
				
				driver.findElement(By.id(property)).click();
				break;
			}
			else if (locator.equals("NAME")) {
				
				driver.findElement(By.name(property)).click();
				break;
			}
			
			break;
		case "SETTEXT":
			if (locator.equals("XPATH")) {
				
				driver.findElement(By.xpath(property)).sendKeys(value);
				break;
				
			}
			else if (locator.equals("ID")) {
				
				driver.findElement(By.id(property)).sendKeys(value);
				break;
			}
			else if (locator.equals("NAME")) {
				
				driver.findElement(By.name(property)).sendKeys(value);
				break;
			}
			
			break;
		case "SELECT":
			if (locator.equals("XPATH")) {
				
				Select select= new Select(driver.findElement(By.xpath(property)));				
				select.selectByVisibleText(value);
				break;
				
			}
			else if (locator.equals("ID")) {
				
				Select select= new Select(driver.findElement(By.id(property)));				
				select.selectByVisibleText(value);
				break;
			}
			else if (locator.equals("NAME")) {
				
				Select select= new Select(driver.findElement(By.name(property)));				
				select.selectByVisibleText(value);
				break;
			}
			
			break;
		case "VERIFY":
			if (locator.equals("XPATH")) {
				
				String getvalue=driver.findElement(By.xpath(property)).getText();
				break;
			}
			else if (locator.equals("ID")) {
				
				String getvalue=driver.findElement(By.id(property)).getText();
				break;
			}
			else if (locator.equals("NAME")) {
				
				String getvalue=driver.findElement(By.name(property)).getText();
				break;
			}
			
			break;
		}
		
	}

}
