package com.Automation.RecoAccounts;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.RecoAccounts.Utility.BrowserFactory;
import com.RecoAccounts.Utility.ExcelDataProvider;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
//import com.aventstack.extentreports.reporter.ExtentReporter;
//import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class BaseClass {

	public WebDriver driver;
	public ExcelDataProvider excel;
	public ExtentReports extent;
	public ExtentTest test;

	@BeforeSuite
	public void ExcelData() {

		excel = new ExcelDataProvider();
	
		
	//	ExtentSparkReporter reporter = new ExtentSparkReporter(System.getProperty("user.dir") +"./Reports/repo.html");
		ExtentHtmlReporter reporter= new ExtentHtmlReporter(new File(System.getProperty("user.dir")+"/Reports/repo.html"));
		//ExtentHtmlReporter reporter= new ExtentHtmlReporter("D:\\workspace\\RecoAccounts\\Reports\\repo.html");
		reporter.config().setDocumentTitle("RecoAccounts");
		reporter.config().setReportName("Testing");
		extent = new ExtentReports();
		extent.attachReporter(reporter);

	}

	@BeforeClass
	public void Setup() {
		driver = BrowserFactory.getBrowser(driver, "Chrome", "http://demo.recoaccounts.com");
	}

	@AfterClass
	public void SetDown() {

		BrowserFactory.quitbrowser(driver);
	}

}
