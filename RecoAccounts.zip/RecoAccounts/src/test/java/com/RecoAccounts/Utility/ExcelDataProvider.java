package com.RecoAccounts.Utility;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDataProvider {

	XSSFWorkbook wb;

	public ExcelDataProvider() {
		try {

			File src = new File("./TestData/TestData.xlsx");
			FileInputStream fi = new FileInputStream(src);
			wb = new XSSFWorkbook(fi);

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public String getData(String Sheetname, int row, int col) {

		return wb.getSheet(Sheetname).getRow(row).getCell(col).getStringCellValue();
		
	}

	public double getNumericData(String Sheetname, int row, int col) {

		return wb.getSheet(Sheetname).getRow(row).getCell(col).getNumericCellValue();
	}

}
