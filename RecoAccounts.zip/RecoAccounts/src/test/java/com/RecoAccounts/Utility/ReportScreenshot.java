package com.RecoAccounts.Utility;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.io.FileHandler;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ReportScreenshot {
	
	public static void capturescreenshot(WebDriver driver) {
		try {
		
        TakesScreenshot scrShot =((TakesScreenshot)driver);

        //Call getScreenshotAs method to create image file

                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File("./Screenshots/"+getdatetime()+".png");

                //Copy file at destination

                FileHandler.copy(SrcFile, DestFile);
                
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
	}
	public static String getdatetime() {
		
		DateFormat DF= new SimpleDateFormat(getdatetime());
		
		Date currdate = new Date();
		
		return DF.format(currdate);	
		
	}

}
