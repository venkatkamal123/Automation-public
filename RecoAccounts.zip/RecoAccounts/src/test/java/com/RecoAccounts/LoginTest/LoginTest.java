package com.RecoAccounts.LoginTest;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.Automation.RecoAccounts.BaseClass;
import com.Automation.RecoAccounts.CommonLibrary;
import com.RecoAccounts.Utility.BrowserFactory;
import com.RecoAccounts.Utility.ExcelDataProvider;
	
public class LoginTest extends BaseClass {
	
	CommonLibrary cl=new CommonLibrary();
	
	@Test
	public void login()
	{
	
	test=extent.createTest("Login Test");
		
	cl.eventhandle(driver,"SETTEXT", "XPATH", "//*[@id='txtUserId']",excel.getData("Login", 1, 0) );
	test.info("Enter user name");
	cl.eventhandle(driver,"SETTEXT", "XPATH", "//*[@id='txtPassword']",excel.getData("Login", 1, 1) );
	test.info("Enter user name");
	test.pass("click");
	//cl.eventhandle(driver,"CLICK", "XPATH", "//*[@id='btnLogin']","" );
	
			
	}

}
